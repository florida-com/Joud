//Update 25/9/2024 18:04
const Discord = require('discord.js');
const client = new Discord.Client({ ws: { intents: new Discord.Intents(Discord.Intents.ALL) } });
const prefix = "+";
const keepAlive = require('./server')


client.on("ready", () => {
  console.log(`Prefix : ${prefix}`)
  console.log(`https://discord.gg/kvek3R5mJB`)
  client.user.setActivity({ type: "WATCHING", name: `Bleto Community` });
});


client.on("message", message => {

  if (message.content.startsWith(prefix + 'bc')) {
    if (!message.member.hasPermission("ADMINISTRATOR")) {
      return message.reply('لاتملك صلاحية القيام بهذاالأمر')
    }
    else {
      message.delete
      args = message.content.split(" ").slice(1);
      var argresult = args.join(' ');

      message.guild.members.cache.forEach(member => {
        member.send(argresult).then(console.log(`[+] Mensagem com sucesso | ${member.user.username}#${member.user.discriminator}`)).catch(e => console.error(`[-] O membro pode ter DM's desativado ou o Bot Caiu | ${member.user.username}#${member.user.discriminator}`));
      })
      message.channel.send(`:white_check_mark: | **تم الارسال لجميع الاعضاء**`).then(message.delete({ timeout: 15000 }));
    }
  }

})
 

keepAlive();

//تأكد أن الإتضافة مضمونة
client.login("حط توكن يوتك هنا");///By Bleto_YT